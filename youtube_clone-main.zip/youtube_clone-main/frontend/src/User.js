export const person = 'sonali';
